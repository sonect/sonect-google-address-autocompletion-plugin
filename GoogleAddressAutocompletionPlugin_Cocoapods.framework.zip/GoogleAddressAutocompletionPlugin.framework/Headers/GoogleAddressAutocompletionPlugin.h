//
//  GoogleAddressAutocompletionPlugin.h
//  GoogleAddressAutocompletionPlugin
//
//  Created by Ivan Yanakiev on 8.04.20.
//  Copyright © 2020 Ivan Yanakiev. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GoogleAddressAutocompletionPlugin.
FOUNDATION_EXPORT double GoogleAddressAutocompletionPluginVersionNumber;

//! Project version string for GoogleAddressAutocompletionPlugin.
FOUNDATION_EXPORT const unsigned char GoogleAddressAutocompletionPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GoogleAddressAutocompletionPlugin/PublicHeader.h>

#import <GoogleAddressAutocompletionPlugin/SNCGoogleAddressAutocompletionPlugin.h>
